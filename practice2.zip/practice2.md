```python
%matplotlib inline
import numpy as np
from matplotlib_inline import backend_inline
from d2l import torch as d2l

```


```python
def f(x):
    return 3 * x ** 2 - 4 * x
```


```python
def numerical_lim(f,x,h):
    return (f(x + h) - f(x)) / h
h = 0.1
for i in range(5):
    print(f'h={h:5f},numerical limit={numerical_lim(f,1,h):.5f}')
    h*= 0.1
```

    h=0.100000,numerical limit=2.30000
    h=0.010000,numerical limit=2.03000
    h=0.001000,numerical limit=2.00300
    h=0.000100,numerical limit=2.00030
    h=0.000010,numerical limit=2.00003
    


```python
def use_svg_display():  #@save
    """使用svg格式在Jupyter中显示绘图"""
    backend_inline.set_matplotlib_formats('svg')
```


```python
def set_figsize(figsize=(3.5, 2.5)):  #@save
    """设置matplotlib的图表大小"""
    use_svg_display()
    d2l.plt.rcParams['figure.figsize'] = figsize
```


```python
#@save
def set_axes(axes,xlabel,ylabel,xlim,ylim,xscale,yscale,legend):
    axes.set_xlabel(xlabel)
    axes.set_ylabel(ylabel)
    axes.set_xscale(xscale)
    axes.set_yscale(yscale)
    axes.set_xlim(xlim)
    axes.set_ylim(ylim)
    if legend:
        axes.legend(legend)
    axes.grid()
```


```python

#@save
def plot(X,Y=None, xlabel=None,ylabel=None,legend=None,xlim=None,ylim=None,xscale='linear',yscale='linear',fmts=('-','m--','g-','r:'),figsize=(3.5,2.5),axes=None):
    if legend is None:
        legend = []
    set_figsize(figsize)
    axes = axes if axes else d2l.plt.gca()
    
    def has_one_axes(X):
        return(hasattr(X,"ndim") and X.ndim == 1 or isinstance(X, list) and not hasattr([0], "__len__"))
    if has_one_axis(X):
        X = [X]
    if Y is None:
        X,Y = [[]] * len(X),X
    elif has_one_axis(Y):
        Y = [Y]
    if len(X) != len(Y):
        X = X * len(Y)
    axes.cla()
    for x,y, fmt in zip(X,Y,fmts):
        if len(x):
            axes.plot(x,y,fmt)
        else:
            axes.plot(y,fmt)
    set_axes(axes,xlabel,ylabel,xlim,ylim,xscale,yscale,legend)
            
               
```


```python
import matplotlib.pyplot as plt

plt.plot(x, y1)
plt.plot(x, y2)
plt.show()
```


    
![png](output_7_0.png)
    



```python
import torch

print("CUDA available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print(torch.cuda.get_device_name(0))
    print(torch.cuda.memory_summary())
```

    CUDA available: False
    


```python
for name in ["model", "data", "loss"]:
    if name in globals():
        del globals()[name]

import torch
torch.cuda.empty_cache()  # CUDA 不可用时没有实际作用
```


```python
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
```

    cpu
    


```python
x = np.arange(0, 3, 0.1)
print(x.shape, x[:5])

y1 = f(x)
print(y1.shape, y1[:5])

y2 = 2 * x - 3
print(y2.shape, y2[:5])
```

    (30,) [0.  0.1 0.2 0.3 0.4]
    (30,) [ 0.   -0.37 -0.68 -0.93 -1.12]
    (30,) [-3.  -2.8 -2.6 -2.4 -2.2]
    


```python
import matplotlib.pyplot as plt

plt.plot(x, y1)
plt.plot(x, y2)
plt.show()
```


    
![png](output_12_0.png)
    



```python
%matplotlib inline
import matplotlib
print(matplotlib.get_backend())

import matplotlib.pyplot as plt
plt.plot([1, 2, 3], [1, 4, 9])
```

    module://ipykernel.pylab.backend_inline
    




    [<matplotlib.lines.Line2D at 0x21eb453c400>]




    
![png](output_13_2.png)
    



```python
def f(x):
    return x**2
```


```python
import numpy as np
import matplotlib.pyplot as plt

x = np.arange(0, 3, 0.1)
y1 = f(x)          # 如果前面定义过 f
y2 = 2 * x - 3

plt.plot(x, y1)
plt.plot(x, y2)
plt.show()
```


    
![png](output_15_0.png)
    



```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python
%matplotlib inline
import numpy as np
from matplotlib_inline import backend_inline
from d2l import torch as d2l


def f(x):
    return 3 * x ** 2 - 4 * x
```


```python
def numerical_lim(f, x, h):
    return (f(x + h) - f(x)) / h

h = 0.1
for i in range(5):
    print(f'h={h:.5f}, numerical limit={numerical_lim(f, 1, h):.5f}')
    h *= 0.1
```

    h=0.10000, numerical limit=2.30000
    h=0.01000, numerical limit=2.03000
    h=0.00100, numerical limit=2.00300
    h=0.00010, numerical limit=2.00030
    h=0.00001, numerical limit=2.00003
    


```python
def use_svg_display():  #@save
    """使用svg格式在Jupyter中显示绘图"""
    backend_inline.set_matplotlib_formats('svg')
```


```python
def set_figsize(figsize=(3.5, 2.5)):  #@save
    """设置matplotlib的图表大小"""
    use_svg_display()
    d2l.plt.rcParams['figure.figsize'] = figsize
```


```python
#@save
def set_axes(axes, xlabel, ylabel, xlim, ylim, xscale, yscale, legend):
    """设置matplotlib的轴"""
    axes.set_xlabel(xlabel)
    axes.set_ylabel(ylabel)
    axes.set_xscale(xscale)
    axes.set_yscale(yscale)
    axes.set_xlim(xlim)
    axes.set_ylim(ylim)
    if legend:
        axes.legend(legend)
    axes.grid()
```


```python
#@save
def plot(X, Y=None, xlabel=None, ylabel=None, legend=None, xlim=None,
         ylim=None, xscale='linear', yscale='linear',
         fmts=('-', 'm--', 'g-.', 'r:'), figsize=(3.5, 2.5), axes=None):
    """绘制数据点"""
    if legend is None:
        legend = []

    set_figsize(figsize)
    axes = axes if axes else d2l.plt.gca()

    # 如果X有一个轴，输出True
    def has_one_axis(X):
        return (hasattr(X, "ndim") and X.ndim == 1 or isinstance(X, list)
                and not hasattr(X[0], "__len__"))

    if has_one_axis(X):
        X = [X]
    if Y is None:
        X, Y = [[]] * len(X), X
    elif has_one_axis(Y):
        Y = [Y]
    if len(X) != len(Y):
        X = X * len(Y)
    axes.cla()
    for x, y, fmt in zip(X, Y, fmts):
        if len(x):
            axes.plot(x, y, fmt)
        else:
            axes.plot(y, fmt)
    set_axes(axes, xlabel, ylabel, xlim, ylim, xscale, yscale, legend)
```


```python
x = np.arange(0, 3, 0.1)
plot(x, [f(x), 2 * x - 3], 'x', 'f(x)', legend=['f(x)', 'Tangent line (x=1)'])
```


    
![svg](output_28_0.svg)
    



```python
import torch

x = torch.arange(4.0)
x
```




    tensor([0., 1., 2., 3.])




```python
x.requires_grad_(True)
x.grad
```


```python
y = 2 * torch.dot(x,x)
y
```




    tensor(28., grad_fn=<MulBackward0>)




```python
y.backward()
x.grad
```




    tensor([ 0.,  4.,  8., 12.])




```python
x.grad == 4 * x
```




    tensor([True, True, True, True])




```python
x.grad.zero_()
y = x.sum()
y.backward()
x.grad
```




    tensor([1., 1., 1., 1.])




```python
import torch

x = torch.tensor(3.0,requires_grad=True)

y = x**2
y.backward()
print(x.grad)
```

    tensor(6.)
    


```python
x.grad.zero_()
y = x * x

y.sum().backward()
x.grad
```




    tensor(6.)




```python
x.grad.zero_()
y = x * x
u = y.detach()
z = u * x

z.sum().backward()
x.grad == u
```




    tensor(True)




```python
x.grad.zero_()
y.sum().backward()
x.grad == 2 * x
```




    tensor(True)




```python
def f(a):
    b = a * 2
    while b.norm() < 1000:
        b = b * 2
    if b.sum() > 0:
        c = b
    else:
        c = 100 * b
    return c
```


```python
a = torch.randn(size=(), requires_grad=True)
d = f(a)
d.backward()
```


```python
a.grad ==d / a
```




    tensor(True)




```python
%matplotlib inline
import torch
from torch.distributions import multinomial
from d2l import torch as d2l

```


```python
fair_probs = torch.ones([6]) / 6
multinomial.Multinomial(1,fair_probs).sample()
```




    tensor([0., 0., 0., 0., 1., 0.])




```python
multinomial.Multinomial(10,fair_probs).sample()
```




    tensor([1., 1., 2., 3., 0., 3.])




```python
counts = multinomial.Multinomial(1000,fair_probs).sample()
counts / 1000
```




    tensor([0.1810, 0.1640, 0.1530, 0.1690, 0.1800, 0.1530])




```python
counts = multinomial.Multinomial(10,fair_probs).sample((500,))
cum_counts = counts.cumsum(dim=0)
estimates = cum_counts / cum_counts.sum(dim=1, keepdims=True)

d2l.set_figsize((6,4.5))
for i in range(6):
    d2l.plt.plot(estimates[:,i].numpy(),label=("P(die=" + str(i + 1) + ")"))
d2l.plt.axhline(y=0.167, color='black', linestyle='dashed')
d2l.plt.gca().set_xlabel('Groups of experiments')
d2l.plt.gca().set_ylabel('Estimated probability')
d2l.plt.legend();
```


    
![svg](output_46_0.svg)
    



```python

```
